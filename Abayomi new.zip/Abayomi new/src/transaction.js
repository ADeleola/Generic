const express = require('express');
const bodyParser = require('body-parser');
const basicAuth = require('express-basic-auth');
const swaggerUi = require('swagger-ui-express');
const swaggerDocument = require('./docs/swagger.json'); // Use the correct path

const app = express();
const PORT = process.env.PORT || 3000;

// In-memory database for transaction records
let transactions = [];

// Middleware
app.use(bodyParser.json());

// Basic Authentication
const users = {
  admin: 'password123' // Sample user
};

app.use(basicAuth({
  users,
  unauthorizedResponse: (req) => {
    return 'Unauthorized';
  }
}));

// API endpoints
app.post('/transactions', (req, res) => {
  const { amount, currency, cardNumber, expiryDate, cvv } = req.body;
  
  // Mock logic for processing transaction
  const transactionId = Math.floor(Math.random() * 1000000);
  const transaction = {
    id: transactionId,
    amount,
    currency,
    cardNumber,
    status: 'pending'
  };

  transactions.push(transaction);

  res.json({ transactionId });
});

app.get('/transactions/:id', (req, res) => {
  const { id } = req.params;

  const transaction = transactions.find(t => t.id === parseInt(id));

  if (!transaction) {
    return res.status(404).json({ error: 'Transaction not found' });
  }

  res.json(transaction);
});

// Webhook endpoint for transaction updates
app.post('/webhook', (req, res) => {
  const { transactionId, status } = req.body;

  const transaction = transactions.find(t => t.id === parseInt(transactionId));

  if (!transaction) {
    return res.status(404).json({ error: 'Transaction not found' });
  }

  transaction.status = status;

  res.json({ message: 'Transaction status updated' });
});

// Swagger documentation
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerDocument));

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
