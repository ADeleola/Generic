const express = require('express');
const app = express();

app.use(express.json())

const port = 2024;
app.listen(port, () => console.log(`Running Express server on port ${port}!`));

const groceriesList = [
    {
        item: 'milk',
        quantity: 2,
        amount: 300
    },
    {
        item: 'Rice',
        quantity: 500,
        amount: 30000
    },
    {
        item: 'Egg',
        quantity: 12,
        amount: 12000
    }
];

app.get('/groceries', (req, res) => {
    res.send(groceriesList);
});

app.post('/groceries', (req, res) => {
    console.log(req.body); // Assuming you're using body-parser middleware to parse the request body
    // Here you can add the received item to the groceries list
    res.status(201).send(); // Sending status 201 (Created) as response
});
